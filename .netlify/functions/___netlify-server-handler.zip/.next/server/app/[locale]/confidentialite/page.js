(()=>{var e={};e.id=696,e.ids=[696],e.modules={47849:e=>{"use strict";e.exports=require("next/dist/client/components/action-async-storage.external")},72934:e=>{"use strict";e.exports=require("next/dist/client/components/action-async-storage.external.js")},55403:e=>{"use strict";e.exports=require("next/dist/client/components/request-async-storage.external")},54580:e=>{"use strict";e.exports=require("next/dist/client/components/request-async-storage.external.js")},94749:e=>{"use strict";e.exports=require("next/dist/client/components/static-generation-async-storage.external")},45869:e=>{"use strict";e.exports=require("next/dist/client/components/static-generation-async-storage.external.js")},20399:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},87653:(e,t,s)=>{"use strict";s.r(t),s.d(t,{GlobalError:()=>i.a,__next_app__:()=>x,originalPathname:()=>d,pages:()=>u,routeModule:()=>p,tree:()=>c});var n=s(50482),o=s(69108),r=s(62563),i=s.n(r),a=s(68300),l={};for(let e in a)0>["default","tree","pages","GlobalError","originalPathname","__next_app__","routeModule"].indexOf(e)&&(l[e]=()=>a[e]);s.d(t,l);let c=["",{children:["[locale]",{children:["confidentialite",{children:["__PAGE__",{},{page:[()=>Promise.resolve().then(s.bind(s,27674)),"/home/moltbotv2/clawd/projects/natura-parquet/site/src/app/[locale]/confidentialite/page.tsx"]}]},{}]},{layout:[()=>Promise.resolve().then(s.bind(s,36999)),"/home/moltbotv2/clawd/projects/natura-parquet/site/src/app/[locale]/layout.tsx"]}]},{"not-found":[()=>Promise.resolve().then(s.t.bind(s,69361,23)),"next/dist/client/components/not-found-error"]}],u=["/home/moltbotv2/clawd/projects/natura-parquet/site/src/app/[locale]/confidentialite/page.tsx"],d="/[locale]/confidentialite/page",x={require:s,loadChunk:()=>Promise.resolve()},p=new n.AppPageRouteModule({definition:{kind:o.x.APP_PAGE,page:"/[locale]/confidentialite/page",pathname:"/[locale]/confidentialite",bundlePath:"",filename:"",appPaths:[]},userland:{loaderTree:c}})},94988:(e,t,s)=>{Promise.resolve().then(s.bind(s,9303))},9303:(e,t,s)=>{"use strict";s.r(t),s.d(t,{default:()=>a});var n=s(95344),o=s(83877),r=s(6765),i=s(84192);function a(){let e=(0,o.useLocale)(),t={fr:{title:"Politique de Confidentialit\xe9",lastUpdate:"Derni\xe8re mise \xe0 jour : 20 f\xe9vrier 2026",sections:[{title:"1. Introduction",content:`EPENON Active SARL, exploitant la marque "Natura Parquets", s'engage \xe0 prot\xe9ger la vie priv\xe9e des utilisateurs de son site www.natura-parquets.fr.

Cette politique de confidentialit\xe9 explique comment nous collectons, utilisons et prot\xe9geons vos donn\xe9es personnelles, conform\xe9ment au R\xe8glement G\xe9n\xe9ral sur la Protection des Donn\xe9es (RGPD).`},{title:"2. Responsable du traitement",content:`**EPENON Active SARL**
6 rue du Commerce
68420 Herrlisheim-pr\xe8s-Colmar
France
Email : contact@natura-parquets.fr
T\xe9l\xe9phone : 06 12 78 61 85`},{title:"3. Donn\xe9es collect\xe9es",content:`Nous collectons les donn\xe9es suivantes :

**Donn\xe9es que vous nous fournissez :**
- Nom et pr\xe9nom
- Adresse email
- Num\xe9ro de t\xe9l\xe9phone
- Adresse postale
- Informations de paiement (trait\xe9es de mani\xe8re s\xe9curis\xe9e par notre prestataire de paiement)

**Donn\xe9es collect\xe9es automatiquement :**
- Adresse IP
- Type de navigateur
- Pages visit\xe9es
- Date et heure de connexion
- Cookies`},{title:"4. Finalit\xe9s du traitement",content:`Vos donn\xe9es sont utilis\xe9es pour :

- Traiter et suivre vos commandes
- G\xe9rer votre compte client
- Vous contacter concernant vos commandes
- R\xe9pondre \xe0 vos demandes d'information
- Envoyer des communications commerciales (avec votre consentement)
- Am\xe9liorer notre site et nos services
- Respecter nos obligations l\xe9gales`},{title:"5. Base l\xe9gale",content:`Le traitement de vos donn\xe9es repose sur :

- **L'ex\xe9cution du contrat** : traitement des commandes
- **Votre consentement** : envoi de newsletters, cookies non essentiels
- **L'int\xe9r\xeat l\xe9gitime** : am\xe9lioration des services, pr\xe9vention de la fraude
- **L'obligation l\xe9gale** : conservation des factures, obligations fiscales`},{title:"6. Dur\xe9e de conservation",content:`Nous conservons vos donn\xe9es :

- **Donn\xe9es clients** : pendant la dur\xe9e de la relation commerciale + 3 ans
- **Donn\xe9es de commande** : 10 ans (obligations comptables)
- **Donn\xe9es de prospection** : 3 ans apr\xe8s le dernier contact
- **Cookies** : 13 mois maximum`},{title:"7. Destinataires des donn\xe9es",content:`Vos donn\xe9es peuvent \xeatre transmises \xe0 :

- Nos \xe9quipes internes (vente, logistique, comptabilit\xe9)
- Nos prestataires de services (h\xe9bergement, paiement, livraison)
- Les autorit\xe9s comp\xe9tentes (sur r\xe9quisition l\xe9gale)

Nous ne vendons jamais vos donn\xe9es \xe0 des tiers.`},{title:"8. Transferts hors UE",content:`Certains de nos prestataires peuvent \xeatre situ\xe9s hors de l'Union europ\xe9enne. Dans ce cas, nous nous assurons que des garanties appropri\xe9es sont en place (clauses contractuelles types, certification Privacy Shield, etc.).`},{title:"9. Vos droits",content:`Conform\xe9ment au RGPD, vous disposez des droits suivants :

- **Droit d'acc\xe8s** : obtenir une copie de vos donn\xe9es
- **Droit de rectification** : corriger vos donn\xe9es inexactes
- **Droit \xe0 l'effacement** : demander la suppression de vos donn\xe9es
- **Droit \xe0 la limitation** : limiter le traitement de vos donn\xe9es
- **Droit \xe0 la portabilit\xe9** : recevoir vos donn\xe9es dans un format structur\xe9
- **Droit d'opposition** : vous opposer au traitement de vos donn\xe9es
- **Droit de retirer votre consentement** : \xe0 tout moment

Pour exercer ces droits, contactez-nous \xe0 : contact@natura-parquets.fr

Vous avez \xe9galement le droit d'introduire une r\xe9clamation aupr\xe8s de la CNIL (www.cnil.fr).`},{title:"10. Cookies",content:`Notre site utilise des cookies :

**Cookies essentiels :**
- Session utilisateur
- Panier d'achat
- Pr\xe9f\xe9rences de langue

**Cookies analytiques (avec consentement) :**
- Google Analytics
- Statistiques de visite

Vous pouvez g\xe9rer vos pr\xe9f\xe9rences de cookies via le bandeau affich\xe9 lors de votre premi\xe8re visite ou dans les param\xe8tres de votre navigateur.`},{title:"11. S\xe9curit\xe9",content:`Nous mettons en œuvre des mesures de s\xe9curit\xe9 appropri\xe9es pour prot\xe9ger vos donn\xe9es :

- Chiffrement SSL/TLS pour toutes les transmissions
- Acc\xe8s restreint aux donn\xe9es personnelles
- Sauvegarde r\xe9guli\xe8re des donn\xe9es
- Mise \xe0 jour r\xe9guli\xe8re de nos syst\xe8mes`},{title:"12. Modification de la politique",content:`Nous pouvons modifier cette politique de confidentialit\xe9 \xe0 tout moment. La date de derni\xe8re mise \xe0 jour est indiqu\xe9e en haut de cette page. Nous vous encourageons \xe0 la consulter r\xe9guli\xe8rement.`},{title:"13. Contact",content:`Pour toute question concernant cette politique ou vos donn\xe9es personnelles :

**EPENON Active SARL**
6 rue du Commerce
68420 Herrlisheim-pr\xe8s-Colmar
France

Email : contact@natura-parquets.fr
T\xe9l\xe9phone : 06 12 78 61 85`}]},de:{title:"Datenschutzerkl\xe4rung",lastUpdate:"Letzte Aktualisierung: 20. Februar 2026",sections:[{title:"1. Einleitung",content:`EPENON Active SARL, die die Marke "Natura Parquets" betreibt, verpflichtet sich, die Privatsph\xe4re der Benutzer ihrer Website www.natura-parquets.fr zu sch\xfctzen.`},{title:"2. Verantwortlicher",content:`**EPENON Active SARL**
6 rue du Commerce
68420 Herrlisheim-pr\xe8s-Colmar
Frankreich
E-Mail: contact@natura-parquets.fr`}]},en:{title:"Privacy Policy",lastUpdate:"Last updated: February 20, 2026",sections:[{title:"1. Introduction",content:'EPENON Active SARL, operating the brand "Natura Parquets", is committed to protecting the privacy of users of its website www.natura-parquets.fr.'},{title:"2. Data Controller",content:`**EPENON Active SARL**
6 rue du Commerce
68420 Herrlisheim-pr\xe8s-Colmar
France
Email: contact@natura-parquets.fr`}]}}[e];return(0,n.jsxs)("main",{className:"min-h-screen bg-white",children:[n.jsx(r.default,{}),n.jsx("article",{className:"py-16 px-6 mt-20",children:(0,n.jsxs)("div",{className:"max-w-3xl mx-auto",children:[n.jsx("h1",{className:"font-display text-4xl text-natura-900 mb-2",children:t.title}),n.jsx("p",{className:"text-natura-500 text-sm mb-12",children:t.lastUpdate}),n.jsx("div",{className:"space-y-10",children:t.sections.map((e,t)=>(0,n.jsxs)("section",{children:[n.jsx("h2",{className:"font-semibold text-xl text-natura-900 mb-4",children:e.title}),n.jsx("div",{className:"text-natura-600 leading-relaxed prose prose-natura max-w-none",dangerouslySetInnerHTML:{__html:e.content.replace(/\*\*(.*?)\*\*/g,"<strong>$1</strong>").replace(/\n/g,"<br />")}})]},t))})]})}),n.jsx(i.default,{})]})}},27674:(e,t,s)=>{"use strict";s.r(t),s.d(t,{$$typeof:()=>r,__esModule:()=>o,default:()=>i});let n=(0,s(86843).createProxy)(String.raw`/home/moltbotv2/clawd/projects/natura-parquet/site/src/app/[locale]/confidentialite/page.tsx`),{__esModule:o,$$typeof:r}=n,i=n.default}};var t=require("../../../webpack-runtime.js");t.C(e);var s=e=>t(t.s=e),n=t.X(0,[638,356,187,691,253,953],()=>s(87653));module.exports=n})();