(()=>{var e={};e.id=693,e.ids=[693],e.modules={47849:e=>{"use strict";e.exports=require("next/dist/client/components/action-async-storage.external")},72934:e=>{"use strict";e.exports=require("next/dist/client/components/action-async-storage.external.js")},55403:e=>{"use strict";e.exports=require("next/dist/client/components/request-async-storage.external")},54580:e=>{"use strict";e.exports=require("next/dist/client/components/request-async-storage.external.js")},94749:e=>{"use strict";e.exports=require("next/dist/client/components/static-generation-async-storage.external")},45869:e=>{"use strict";e.exports=require("next/dist/client/components/static-generation-async-storage.external.js")},20399:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},58704:(e,t,s)=>{"use strict";s.r(t),s.d(t,{GlobalError:()=>a.a,__next_app__:()=>x,originalPathname:()=>d,pages:()=>u,routeModule:()=>p,tree:()=>c});var r=s(50482),i=s(69108),n=s(62563),a=s.n(n),o=s(68300),l={};for(let e in o)0>["default","tree","pages","GlobalError","originalPathname","__next_app__","routeModule"].indexOf(e)&&(l[e]=()=>o[e]);s.d(t,l);let c=["",{children:["[locale]",{children:["mentions-legales",{children:["__PAGE__",{},{page:[()=>Promise.resolve().then(s.bind(s,24959)),"/home/moltbotv2/clawd/projects/natura-parquet/site/src/app/[locale]/mentions-legales/page.tsx"]}]},{}]},{layout:[()=>Promise.resolve().then(s.bind(s,36999)),"/home/moltbotv2/clawd/projects/natura-parquet/site/src/app/[locale]/layout.tsx"]}]},{"not-found":[()=>Promise.resolve().then(s.t.bind(s,69361,23)),"next/dist/client/components/not-found-error"]}],u=["/home/moltbotv2/clawd/projects/natura-parquet/site/src/app/[locale]/mentions-legales/page.tsx"],d="/[locale]/mentions-legales/page",x={require:s,loadChunk:()=>Promise.resolve()},p=new r.AppPageRouteModule({definition:{kind:i.x.APP_PAGE,page:"/[locale]/mentions-legales/page",pathname:"/[locale]/mentions-legales",bundlePath:"",filename:"",appPaths:[]},userland:{loaderTree:c}})},30278:(e,t,s)=>{Promise.resolve().then(s.bind(s,36525))},36525:(e,t,s)=>{"use strict";s.r(t),s.d(t,{default:()=>o});var r=s(95344),i=s(83877),n=s(6765),a=s(84192);function o(){let e=(0,i.useLocale)(),t={fr:{title:"Mentions L\xe9gales",lastUpdate:"Derni\xe8re mise \xe0 jour : 20 f\xe9vrier 2026",sections:[{title:"1. \xc9diteur du site",content:`Le site www.natura-parquets.fr est \xe9dit\xe9 par :

**EPENON Active SARL**
Soci\xe9t\xe9 \xe0 responsabilit\xe9 limit\xe9e (SARL)
Capital social : [\xc0 compl\xe9ter]

**Si\xe8ge social :**
6 rue du Commerce
68420 Herrlisheim-pr\xe8s-Colmar
France

**Immatriculation :**
- SIREN : 881 601 207
- SIRET (si\xe8ge) : 881 601 207 00015
- N\xb0 TVA intracommunautaire : FR81881601207
- Code APE/NAF : 6630Z (Gestion de fonds)

**Date de cr\xe9ation :** 13 mai 2020

**Direction :** Conseil d'administration Groupe EPENON

**Marque commerciale :** Natura Parquets est une marque de EPENON Active SARL`},{title:"2. Directeur de la publication",content:`Le directeur de la publication du site est :
**EPENON Active SARL**, repr\xe9sent\xe9e par le Conseil d'administration Groupe EPENON.

Contact : contact@natura-parquets.fr`},{title:"3. H\xe9bergement",content:`Le site est h\xe9berg\xe9 par :

**Netlify, Inc.**
2325 3rd Street, Suite 296
San Francisco, California 94107
\xc9tats-Unis

Site web : www.netlify.com`},{title:"4. Propri\xe9t\xe9 intellectuelle",content:`L'ensemble du contenu de ce site (textes, images, vid\xe9os, logos, graphismes, ic\xf4nes, sons, logiciels, etc.) est la propri\xe9t\xe9 exclusive de EPENON Active SARL ou de ses partenaires et est prot\xe9g\xe9 par les lois fran\xe7aises et internationales relatives \xe0 la propri\xe9t\xe9 intellectuelle.

Toute reproduction, repr\xe9sentation, modification, publication, transmission, d\xe9naturation, totale ou partielle du site ou de son contenu, par quelque proc\xe9d\xe9 que ce soit, et sur quelque support que ce soit, est interdite sans l'autorisation \xe9crite pr\xe9alable de EPENON Active SARL.

La marque "Natura Parquets" et le logo associ\xe9 sont des marques d\xe9pos\xe9es. Toute reproduction est interdite.`},{title:"5. Donn\xe9es personnelles",content:`EPENON Active SARL s'engage \xe0 respecter la r\xe9glementation en vigueur applicable au traitement de donn\xe9es \xe0 caract\xe8re personnel, et notamment le R\xe8glement (UE) 2016/679 du Parlement europ\xe9en et du Conseil du 27 avril 2016 (RGPD).

**Responsable du traitement :**
EPENON Active SARL
6 rue du Commerce
68420 Herrlisheim-pr\xe8s-Colmar
Email : contact@natura-parquets.fr

**Donn\xe9es collect\xe9es :**
- Donn\xe9es de contact (nom, email, t\xe9l\xe9phone)
- Donn\xe9es de navigation (cookies)
- Donn\xe9es de commande

**Finalit\xe9s :**
- Traitement des commandes
- Gestion de la relation client
- Envoi de communications commerciales (avec consentement)
- Am\xe9lioration du site

**Dur\xe9e de conservation :**
Les donn\xe9es sont conserv\xe9es pendant la dur\xe9e n\xe9cessaire aux finalit\xe9s pour lesquelles elles sont collect\xe9es, et au maximum 3 ans apr\xe8s le dernier contact.

**Vos droits :**
Conform\xe9ment au RGPD, vous disposez d'un droit d'acc\xe8s, de rectification, d'effacement, de limitation, de portabilit\xe9 et d'opposition au traitement de vos donn\xe9es personnelles.

Pour exercer ces droits, contactez-nous \xe0 : contact@natura-parquets.fr`},{title:"6. Cookies",content:`Le site utilise des cookies pour am\xe9liorer l'exp\xe9rience utilisateur et analyser le trafic.

**Types de cookies utilis\xe9s :**
- Cookies essentiels (fonctionnement du site)
- Cookies analytiques (statistiques de visite)
- Cookies de pr\xe9f\xe9rence (langue, panier)

Vous pouvez configurer votre navigateur pour refuser les cookies. Cependant, certaines fonctionnalit\xe9s du site pourraient ne plus \xeatre disponibles.`},{title:"7. Limitation de responsabilit\xe9",content:`EPENON Active SARL s'efforce d'assurer au mieux de ses possibilit\xe9s l'exactitude et la mise \xe0 jour des informations diffus\xe9es sur ce site. Toutefois, EPENON Active SARL ne peut garantir l'exactitude, la pr\xe9cision ou l'exhaustivit\xe9 des informations mises \xe0 disposition sur ce site.

EPENON Active SARL d\xe9cline toute responsabilit\xe9 :
- Pour toute interruption du site
- Pour toute survenance de bugs
- Pour toute inexactitude ou omission portant sur des informations disponibles sur le site
- Pour tout dommage r\xe9sultant d'une intrusion frauduleuse d'un tiers`},{title:"8. Liens hypertextes",content:`Le site peut contenir des liens vers d'autres sites internet. EPENON Active SARL n'exerce aucun contr\xf4le sur ces sites et d\xe9cline toute responsabilit\xe9 quant \xe0 leur contenu.`},{title:"9. Droit applicable",content:`Les pr\xe9sentes mentions l\xe9gales sont r\xe9gies par le droit fran\xe7ais. En cas de litige, les tribunaux fran\xe7ais seront seuls comp\xe9tents.`},{title:"10. Contact",content:`Pour toute question concernant ces mentions l\xe9gales :

**EPENON Active SARL**
6 rue du Commerce
68420 Herrlisheim-pr\xe8s-Colmar
France

Email : contact@natura-parquets.fr
T\xe9l\xe9phone : 06 12 78 61 85`}]},de:{title:"Impressum",lastUpdate:"Letzte Aktualisierung: 20. Februar 2026",sections:[{title:"1. Herausgeber der Website",content:`Die Website www.natura-parquets.fr wird herausgegeben von:

**EPENON Active SARL**
Gesellschaft mit beschr\xe4nkter Haftung

**Sitz:**
6 rue du Commerce
68420 Herrlisheim-pr\xe8s-Colmar
Frankreich

**Registrierung:**
- SIREN: 881 601 207
- SIRET: 881 601 207 00015
- USt-IdNr.: FR81881601207

**Leitung:** Vorstand Gruppe EPENON

**Handelsmarke:** Natura Parquets ist eine Marke von EPENON Active SARL`},{title:"2. Verantwortlich f\xfcr den Inhalt",content:`Verantwortlich: EPENON Active SARL, vertreten durch den Vorstand Gruppe EPENON

Kontakt: contact@natura-parquets.fr`}]},en:{title:"Legal Notice",lastUpdate:"Last updated: February 20, 2026",sections:[{title:"1. Website Publisher",content:`The website www.natura-parquets.fr is published by:

**EPENON Active SARL**
Limited Liability Company

**Registered Office:**
6 rue du Commerce
68420 Herrlisheim-pr\xe8s-Colmar
France

**Registration:**
- SIREN: 881 601 207
- SIRET: 881 601 207 00015
- VAT Number: FR81881601207

**Management:** EPENON Group Board of Directors

**Trademark:** Natura Parquets is a brand of EPENON Active SARL`},{title:"2. Publication Director",content:`Publication Director: EPENON Active SARL, represented by EPENON Group Board of Directors

Contact: contact@natura-parquets.fr`}]}}[e];return(0,r.jsxs)("main",{className:"min-h-screen bg-white",children:[r.jsx(n.default,{}),r.jsx("article",{className:"py-16 px-6 mt-20",children:(0,r.jsxs)("div",{className:"max-w-3xl mx-auto",children:[r.jsx("h1",{className:"font-display text-4xl text-natura-900 mb-2",children:t.title}),r.jsx("p",{className:"text-natura-500 text-sm mb-12",children:t.lastUpdate}),r.jsx("div",{className:"space-y-10",children:t.sections.map((e,t)=>(0,r.jsxs)("section",{children:[r.jsx("h2",{className:"font-semibold text-xl text-natura-900 mb-4",children:e.title}),r.jsx("div",{className:"text-natura-600 leading-relaxed prose prose-natura max-w-none",dangerouslySetInnerHTML:{__html:e.content.replace(/\*\*(.*?)\*\*/g,"<strong>$1</strong>").replace(/\n/g,"<br />")}})]},t))})]})}),r.jsx(a.default,{})]})}},24959:(e,t,s)=>{"use strict";s.r(t),s.d(t,{$$typeof:()=>n,__esModule:()=>i,default:()=>a});let r=(0,s(86843).createProxy)(String.raw`/home/moltbotv2/clawd/projects/natura-parquet/site/src/app/[locale]/mentions-legales/page.tsx`),{__esModule:i,$$typeof:n}=r,a=r.default}};var t=require("../../../webpack-runtime.js");t.C(e);var s=e=>t(t.s=e),r=t.X(0,[638,356,187,691,253,953],()=>s(58704));module.exports=r})();