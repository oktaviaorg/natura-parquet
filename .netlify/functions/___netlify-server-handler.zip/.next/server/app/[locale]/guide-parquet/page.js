(()=>{var e={};e.id=517,e.ids=[517],e.modules={47849:e=>{"use strict";e.exports=require("next/dist/client/components/action-async-storage.external")},72934:e=>{"use strict";e.exports=require("next/dist/client/components/action-async-storage.external.js")},55403:e=>{"use strict";e.exports=require("next/dist/client/components/request-async-storage.external")},54580:e=>{"use strict";e.exports=require("next/dist/client/components/request-async-storage.external.js")},94749:e=>{"use strict";e.exports=require("next/dist/client/components/static-generation-async-storage.external")},45869:e=>{"use strict";e.exports=require("next/dist/client/components/static-generation-async-storage.external.js")},20399:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},72901:(e,t,r)=>{"use strict";r.r(t),r.d(t,{GlobalError:()=>i.a,__next_app__:()=>x,originalPathname:()=>m,pages:()=>u,routeModule:()=>p,tree:()=>c});var s=r(50482),a=r(69108),n=r(62563),i=r.n(n),o=r(68300),l={};for(let e in o)0>["default","tree","pages","GlobalError","originalPathname","__next_app__","routeModule"].indexOf(e)&&(l[e]=()=>o[e]);r.d(t,l);let c=["",{children:["[locale]",{children:["guide-parquet",{children:["__PAGE__",{},{page:[()=>Promise.resolve().then(r.bind(r,47743)),"/home/moltbotv2/clawd/projects/natura-parquet/site/src/app/[locale]/guide-parquet/page.tsx"]}]},{}]},{layout:[()=>Promise.resolve().then(r.bind(r,36999)),"/home/moltbotv2/clawd/projects/natura-parquet/site/src/app/[locale]/layout.tsx"]}]},{"not-found":[()=>Promise.resolve().then(r.t.bind(r,69361,23)),"next/dist/client/components/not-found-error"]}],u=["/home/moltbotv2/clawd/projects/natura-parquet/site/src/app/[locale]/guide-parquet/page.tsx"],m="/[locale]/guide-parquet/page",x={require:r,loadChunk:()=>Promise.resolve()},p=new s.AppPageRouteModule({definition:{kind:a.x.APP_PAGE,page:"/[locale]/guide-parquet/page",pathname:"/[locale]/guide-parquet",bundlePath:"",filename:"",appPaths:[]},userland:{loaderTree:c}})},582:(e,t,r)=>{Promise.resolve().then(r.t.bind(r,61476,23)),Promise.resolve().then(r.bind(r,84192)),Promise.resolve().then(r.bind(r,6765))},16274:(e,t,r)=>{"use strict";r.d(t,{default:()=>a.a});var s=r(48026),a=r.n(s)},48026:(e,t,r)=>{"use strict";let{createProxy:s}=r(86843);e.exports=s("/home/moltbotv2/clawd/projects/natura-parquet/site/node_modules/next/dist/client/link.js")},47743:(e,t,r)=>{"use strict";r.r(t),r.d(t,{default:()=>l,metadata:()=>o});var s=r(25036),a=r(72554),n=r(93841),i=r(16274);let o={title:"Guide : Comment choisir son parquet ? | Natura Parquets",description:"D\xe9couvrez notre guide complet pour choisir le parquet id\xe9al. Conseils sur les essences, finitions, dimensions et pose. Expert parquet ch\xeane europ\xe9en.",keywords:"guide parquet, choisir parquet, parquet ch\xeane, finition parquet, pose parquet, parquet contrecoll\xe9"};function l({params:e}){let t=e.locale,r={fr:{title:"Comment choisir son parquet ?",subtitle:"Le guide complet pour faire le bon choix",intro:"Choisir un parquet est une d\xe9cision importante qui impacte l'esth\xe9tique et le confort de votre int\xe9rieur pour de nombreuses ann\xe9es. Ce guide vous accompagne dans votre r\xe9flexion.",sections:[{title:"1. Contrecoll\xe9 ou massif ?",icon:"\uD83E\uDEB5",content:`Le parquet contrecoll\xe9 est aujourd'hui le choix de r\xe9f\xe9rence pour la plupart des projets. Compos\xe9 de plusieurs couches de bois avec une couche noble en surface, il offre :

• **Stabilit\xe9 dimensionnelle** : id\xe9al avec chauffage au sol
• **Pose plus rapide** : syst\xe8me clipsable ou coll\xe9
• **Excellent rapport qualit\xe9-prix**
• **Couche noble de 2.5 \xe0 4mm** : permet 1 \xe0 2 r\xe9novations

Le parquet massif reste pertinent pour les projets patrimoniaux ou les poses traditionnelles.`},{title:"2. Quelle essence de bois ?",icon:"\uD83C\uDF33",content:`Le **ch\xeane europ\xe9en** est l'essence reine pour les parquets. Nos parquets sont issus de for\xeats polonaises certifi\xe9es :

• **Duret\xe9 exceptionnelle** (Brinell 3.7) : r\xe9siste au passage intensif
• **Veinage \xe9l\xe9gant** : mailles et flammes naturelles
• **Tanins protecteurs** : durabilit\xe9 naturelle
• **Teintes vari\xe9es** : du blond au brun dor\xe9

Tous nos parquets sont en ch\xeane europ\xe9en de premi\xe8re qualit\xe9.`},{title:"3. Dimensions des lames",icon:"\uD83D\uDCD0",content:`Le format des lames influence fortement le rendu visuel :

**Largeur**
• **70mm** (compact) : style classique, adapt\xe9 aux petites pi\xe8ces
• **100mm** (chevron) : pose point de Hongrie traditionnelle
• **120mm** (standard) : polyvalent, \xe9quilibre esth\xe9tique/pratique
• **150mm** (large) : effet contemporain, agrandit visuellement l'espace

**Longueur**
• **490-600mm** : format \xe9conomique, coupe limit\xe9e
• **1200-1330mm** : grandes longueurs pour pi\xe8ces spacieuses

**\xc9paisseur**
• **11mm** : standard contrecoll\xe9, parfait sur chauffage au sol
• **14mm** : pour chevrons et lames premium`},{title:"4. Quelle finition choisir ?",icon:"✨",content:`Trois options principales s'offrent \xe0 vous :

**Vernis UV**
• Protection maximale contre l'usure
• Entretien minimal (aspirateur + serpill\xe8re humide)
• Id\xe9al pour les pi\xe8ces \xe0 fort passage
• Rendu l\xe9g\xe8rement satin\xe9

**Huile naturelle**
• Toucher authentique du bois
• R\xe9parations localis\xe9es possibles
• Aspect mat naturel
• Entretien : huile d'entretien 1-2x/an

**Brut (\xe0 finir)**
• Personnalisation totale sur chantier
• Choix de teinte et finition
• N\xe9cessite un professionnel pour la mise en œuvre
• Prix d'achat inf\xe9rieur`},{title:"5. Gamme Exclusive vs \xc9l\xe9gance",icon:"⭐",content:`Nos deux gammes r\xe9pondent \xe0 des besoins diff\xe9rents :

**Gamme Exclusive**
• Couche noble **3.5mm** (2 pon\xe7ages possibles)
• S\xe9lection de bois premium
• Nœuds rares et petits
• Veinage r\xe9gulier et \xe9l\xe9gant

**Gamme \xc9l\xe9gance**
• Couche noble **2.5mm** (1 pon\xe7age possible)
• Excellent rapport qualit\xe9-prix
• Aspect naturel avec quelques nœuds
• Caract\xe8re authentique

**Gamme Rustic**
• Caract\xe8re affirm\xe9 avec nœuds apparents
• Authenticit\xe9 et charme naturel
• Id\xe9al pour les ambiances chaleureuses

**Gamme Country**
• Maximum de caract\xe8re et de rusticit\xe9
• Nœuds, aubier et variations naturelles
• Pour les amoureux du bois brut`},{title:"6. Compatibilit\xe9 chauffage au sol",icon:"\uD83D\uDD25",content:`Tous nos parquets contrecoll\xe9s sont **compatibles chauffage au sol** (eau ou \xe9lectrique basse temp\xe9rature) :

• \xc9paisseur totale ≤ 15mm : bonne conductivit\xe9 thermique
• Structure multicouche stable
• Pose coll\xe9e recommand\xe9e pour optimiser le transfert thermique
• Temp\xe9rature de surface max : 28\xb0C

**Conseil** : pr\xe9voyez une mont\xe9e en temp\xe9rature progressive lors de la premi\xe8re chauffe.`},{title:"7. Calculer la surface n\xe9cessaire",icon:"\uD83E\uDDEE",content:`Pour calculer la quantit\xe9 de parquet :

1. **Mesurez** chaque pi\xe8ce (longueur \xd7 largeur)
2. **Additionnez** les surfaces
3. **Ajoutez 10%** pour les coupes et chutes

**Exemple** :
Salon 25m\xb2 + Chambre 1 (12m\xb2) + Chambre 2 (10m\xb2) = 47m\xb2
Avec marge 10% : **52m\xb2** \xe0 commander

Notre calculateur int\xe9gr\xe9 dans chaque fiche produit fait ce calcul automatiquement.`},{title:"8. D\xe9lais de livraison",icon:"\uD83D\uDCE6",content:`Nos parquets sont fabriqu\xe9s sur commande en Pologne :

• **Stock standard** : 2 semaines
• **Premier choix** : 3-4 semaines
• **Sur-mesure** : 6-8 semaines

Livraison gratuite en France m\xe9tropolitaine, sur rendez-vous.

**Conseil** : commandez suffisamment \xe0 l'avance pour \xe9viter les retards de chantier.`}],cta:{title:"Pr\xeat \xe0 choisir votre parquet ?",subtitle:"D\xe9couvrez notre collection de parquets ch\xeane europ\xe9en premium",button:"Voir nos parquets"},contact:{title:"Besoin d'un conseil personnalis\xe9 ?",text:"Notre \xe9quipe est \xe0 votre disposition pour vous guider dans votre choix.",phone:"06 12 78 61 85",email:"contact@natura-parquets.fr"}},de:{title:"Wie w\xe4hlt man sein Parkett?",subtitle:"Der komplette Leitfaden f\xfcr die richtige Wahl",intro:"Die Wahl eines Parketts ist eine wichtige Entscheidung, die die \xc4sthetik und den Komfort Ihres Interieurs f\xfcr viele Jahre beeinflusst.",sections:[{title:"1. Mehrschicht oder Massiv?",icon:"\uD83E\uDEB5",content:`Mehrschichtparkett ist heute die Referenzwahl f\xfcr die meisten Projekte. Es besteht aus mehreren Holzschichten mit einer Edelholzschicht an der Oberfl\xe4che:

• **Dimensionale Stabilit\xe4t**: ideal mit Fu\xdfbodenheizung
• **Schnellere Verlegung**: Klick- oder Klebesystem
• **Ausgezeichnetes Preis-Leistungs-Verh\xe4ltnis**
• **Edelholzschicht 2,5 bis 4mm**: erm\xf6glicht 1-2 Renovierungen`},{title:"2. Welche Holzart?",icon:"\uD83C\uDF33",content:`**Europ\xe4ische Eiche** ist die K\xf6nigin der Parkettholzarten. Unsere Parkette stammen aus zertifizierten polnischen W\xe4ldern:

• **Au\xdfergew\xf6hnliche H\xe4rte** (Brinell 3,7)
• **Elegante Maserung**: nat\xfcrliche Spiegel und Flammen
• **Sch\xfctzende Tannine**: nat\xfcrliche Haltbarkeit`}],cta:{title:"Bereit, Ihr Parkett zu w\xe4hlen?",subtitle:"Entdecken Sie unsere Kollektion europ\xe4ischer Premium-Eichenparkette",button:"Unsere Parkette ansehen"},contact:{title:"Brauchen Sie pers\xf6nliche Beratung?",text:"Unser Team steht Ihnen gerne zur Verf\xfcgung.",phone:"06 12 78 61 85",email:"contact@natura-parquets.fr"}},en:{title:"How to choose your parquet?",subtitle:"The complete guide to making the right choice",intro:"Choosing a parquet is an important decision that impacts the aesthetics and comfort of your interior for many years.",sections:[{title:"1. Engineered or Solid?",icon:"\uD83E\uDEB5",content:`Engineered parquet is now the reference choice for most projects. Made of multiple wood layers with a noble surface layer:

• **Dimensional stability**: ideal with underfloor heating
• **Faster installation**: click or glue system
• **Excellent value for money**
• **Noble layer 2.5 to 4mm**: allows 1-2 renovations`},{title:"2. Which wood species?",icon:"\uD83C\uDF33",content:`**European oak** is the queen of parquet woods. Our parquets come from certified Polish forests:

• **Exceptional hardness** (Brinell 3.7)
• **Elegant grain**: natural mirrors and flames
• **Protective tannins**: natural durability`}],cta:{title:"Ready to choose your parquet?",subtitle:"Discover our collection of premium European oak parquets",button:"View our parquets"},contact:{title:"Need personalized advice?",text:"Our team is available to guide you.",phone:"06 12 78 61 85",email:"contact@natura-parquets.fr"}}}[t];return(0,s.jsxs)("main",{className:"min-h-screen bg-white",children:[s.jsx(a.ZP,{}),s.jsx("section",{className:"pt-24 pb-16 px-6 bg-gradient-to-b from-natura-100 to-white",children:(0,s.jsxs)("div",{className:"max-w-4xl mx-auto text-center",children:[s.jsx("h1",{className:"font-display text-4xl md:text-5xl text-natura-900 mb-4",children:r.title}),s.jsx("p",{className:"text-xl text-natura-600 mb-6",children:r.subtitle}),s.jsx("p",{className:"text-natura-700 max-w-2xl mx-auto",children:r.intro})]})}),s.jsx("section",{className:"py-16 px-6",children:s.jsx("div",{className:"max-w-4xl mx-auto",children:s.jsx("div",{className:"space-y-16",children:r.sections.map((e,t)=>(0,s.jsxs)("article",{className:"scroll-mt-24",id:`section-${t+1}`,children:[(0,s.jsxs)("div",{className:"flex items-start gap-4 mb-6",children:[s.jsx("span",{className:"text-4xl",children:e.icon}),s.jsx("h2",{className:"font-display text-2xl md:text-3xl text-natura-900",children:e.title})]}),s.jsx("div",{className:"prose prose-natura max-w-none",children:s.jsx("div",{className:"text-natura-700 leading-relaxed whitespace-pre-line",dangerouslySetInnerHTML:{__html:e.content.replace(/\*\*(.*?)\*\*/g,"<strong>$1</strong>").replace(/\n/g,"<br/>")}})})]},t))})})}),s.jsx("section",{className:"py-16 px-6 bg-natura-900",children:(0,s.jsxs)("div",{className:"max-w-4xl mx-auto text-center",children:[s.jsx("h2",{className:"font-display text-3xl text-white mb-4",children:r.cta.title}),s.jsx("p",{className:"text-natura-300 mb-8",children:r.cta.subtitle}),(0,s.jsxs)(i.default,{href:`/${t}/produits`,className:"inline-flex items-center gap-2 px-8 py-4 bg-white text-natura-900 font-medium hover:bg-natura-100 transition-colors rounded-lg",children:[r.cta.button,s.jsx("svg",{className:"w-5 h-5",fill:"none",stroke:"currentColor",viewBox:"0 0 24 24",children:s.jsx("path",{strokeLinecap:"round",strokeLinejoin:"round",strokeWidth:2,d:"M17 8l4 4m0 0l-4 4m4-4H3"})})]})]})}),s.jsx("section",{className:"py-16 px-6 bg-amber-50",children:(0,s.jsxs)("div",{className:"max-w-4xl mx-auto text-center",children:[s.jsx("h2",{className:"font-display text-2xl text-natura-900 mb-4",children:r.contact.title}),s.jsx("p",{className:"text-natura-600 mb-6",children:r.contact.text}),(0,s.jsxs)("div",{className:"flex flex-col sm:flex-row items-center justify-center gap-6",children:[(0,s.jsxs)("a",{href:`tel:${r.contact.phone.replace(/\s/g,"")}`,className:"flex items-center gap-2 text-natura-900 font-medium hover:text-amber-700",children:[s.jsx("svg",{className:"w-5 h-5",fill:"none",stroke:"currentColor",viewBox:"0 0 24 24",children:s.jsx("path",{strokeLinecap:"round",strokeLinejoin:"round",strokeWidth:2,d:"M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z"})}),r.contact.phone]}),(0,s.jsxs)("a",{href:`mailto:${r.contact.email}`,className:"flex items-center gap-2 text-natura-900 font-medium hover:text-amber-700",children:[s.jsx("svg",{className:"w-5 h-5",fill:"none",stroke:"currentColor",viewBox:"0 0 24 24",children:s.jsx("path",{strokeLinecap:"round",strokeLinejoin:"round",strokeWidth:2,d:"M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"})}),r.contact.email]})]})]})}),s.jsx(n.ZP,{})]})}},93841:(e,t,r)=>{"use strict";r.d(t,{ZP:()=>i});let s=(0,r(86843).createProxy)(String.raw`/home/moltbotv2/clawd/projects/natura-parquet/site/src/components/Footer.tsx`),{__esModule:a,$$typeof:n}=s,i=s.default},72554:(e,t,r)=>{"use strict";r.d(t,{ZP:()=>i});let s=(0,r(86843).createProxy)(String.raw`/home/moltbotv2/clawd/projects/natura-parquet/site/src/components/Navigation.tsx`),{__esModule:a,$$typeof:n}=s,i=s.default}};var t=require("../../../webpack-runtime.js");t.C(e);var r=e=>t(t.s=e),s=t.X(0,[638,356,187,691,253,953],()=>r(72901));module.exports=s})();