(()=>{var e={};e.id=548,e.ids=[548],e.modules={47849:e=>{"use strict";e.exports=require("next/dist/client/components/action-async-storage.external")},72934:e=>{"use strict";e.exports=require("next/dist/client/components/action-async-storage.external.js")},55403:e=>{"use strict";e.exports=require("next/dist/client/components/request-async-storage.external")},54580:e=>{"use strict";e.exports=require("next/dist/client/components/request-async-storage.external.js")},94749:e=>{"use strict";e.exports=require("next/dist/client/components/static-generation-async-storage.external")},45869:e=>{"use strict";e.exports=require("next/dist/client/components/static-generation-async-storage.external.js")},20399:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},15723:(e,t,r)=>{"use strict";r.r(t),r.d(t,{GlobalError:()=>i.a,__next_app__:()=>x,originalPathname:()=>u,pages:()=>d,routeModule:()=>p,tree:()=>c});var s=r(50482),a=r(69108),n=r(62563),i=r.n(n),o=r(68300),l={};for(let e in o)0>["default","tree","pages","GlobalError","originalPathname","__next_app__","routeModule"].indexOf(e)&&(l[e]=()=>o[e]);r.d(t,l);let c=["",{children:["[locale]",{children:["cgv",{children:["__PAGE__",{},{page:[()=>Promise.resolve().then(r.bind(r,10586)),"/home/moltbotv2/clawd/projects/natura-parquet/site/src/app/[locale]/cgv/page.tsx"]}]},{}]},{layout:[()=>Promise.resolve().then(r.bind(r,36999)),"/home/moltbotv2/clawd/projects/natura-parquet/site/src/app/[locale]/layout.tsx"]}]},{"not-found":[()=>Promise.resolve().then(r.t.bind(r,69361,23)),"next/dist/client/components/not-found-error"]}],d=["/home/moltbotv2/clawd/projects/natura-parquet/site/src/app/[locale]/cgv/page.tsx"],u="/[locale]/cgv/page",x={require:r,loadChunk:()=>Promise.resolve()},p=new s.AppPageRouteModule({definition:{kind:a.x.APP_PAGE,page:"/[locale]/cgv/page",pathname:"/[locale]/cgv",bundlePath:"",filename:"",appPaths:[]},userland:{loaderTree:c}})},35174:(e,t,r)=>{Promise.resolve().then(r.bind(r,23146))},23146:(e,t,r)=>{"use strict";r.r(t),r.d(t,{default:()=>o});var s=r(95344),a=r(83877),n=r(6765),i=r(84192);function o(){let e=(0,a.useLocale)(),t={fr:{title:"Conditions G\xe9n\xe9rales de Vente",lastUpdate:"Derni\xe8re mise \xe0 jour : 20 f\xe9vrier 2026",sections:[{title:"Article 1 - Objet",content:`Les pr\xe9sentes Conditions G\xe9n\xe9rales de Vente (CGV) r\xe9gissent les ventes de parquets et produits associ\xe9s effectu\xe9es par la soci\xe9t\xe9 EPENON Active SARL, exploitant la marque "Natura Parquets", aupr\xe8s de ses clients professionnels et particuliers via le site www.natura-parquets.fr.

Toute commande implique l'acceptation sans r\xe9serve des pr\xe9sentes CGV.`},{title:"Article 2 - Vendeur",content:`**EPENON Active SARL**
SIREN : 881 601 207
SIRET : 881 601 207 00015
N\xb0 TVA : FR81881601207
Si\xe8ge social : 6 rue du Commerce, 68420 Herrlisheim-pr\xe8s-Colmar
Email : contact@natura-parquets.fr
T\xe9l\xe9phone : 06 12 78 61 85`},{title:"Article 3 - Produits",content:`Les produits propos\xe9s \xe0 la vente sont des parquets en ch\xeane europ\xe9en, ainsi que des produits d'entretien et accessoires associ\xe9s.

Les photographies et descriptions des produits sont donn\xe9es \xe0 titre indicatif. Le bois \xe9tant un mat\xe9riau naturel, des variations de teinte, de veinage et de structure sont normales et ne constituent pas un d\xe9faut.

Les produits sont conformes \xe0 la l\xe9gislation fran\xe7aise et europ\xe9enne en vigueur.`},{title:"Article 4 - Prix",content:`Les prix sont indiqu\xe9s en euros, toutes taxes comprises (TTC), hors frais de livraison.

Les prix applicables sont ceux en vigueur au jour de la commande. EPENON Active SARL se r\xe9serve le droit de modifier ses prix \xe0 tout moment, sans que cela n'affecte les commandes d\xe9j\xe0 valid\xe9es.

Pour les professionnels, les prix peuvent \xeatre communiqu\xe9s hors taxes (HT) sur demande.`},{title:"Article 5 - Commande",content:`**5.1 Passation de commande**
La commande peut \xeatre pass\xe9e :
- Sur le site www.natura-parquets.fr
- Par email \xe0 contact@natura-parquets.fr
- Par t\xe9l\xe9phone au 06 12 78 61 85

**5.2 Validation**
La commande est valid\xe9e apr\xe8s :
- Confirmation \xe9crite par email
- R\xe9ception de l'acompte (30% minimum)

**5.3 Modification / Annulation**
Toute modification ou annulation doit \xeatre demand\xe9e par \xe9crit. Les commandes sur mesure ne peuvent \xeatre annul\xe9es.`},{title:"Article 6 - Paiement",content:`**6.1 Modalit\xe9s de paiement**
Le paiement peut s'effectuer par :
- Virement bancaire
- Ch\xe8que
- Carte bancaire (via paiement s\xe9curis\xe9)

**6.2 Conditions**
- Acompte de 30% \xe0 la commande
- Solde \xe0 r\xe9ception de la marchandise ou avant livraison

**6.3 Retard de paiement**
En cas de retard de paiement, des p\xe9nalit\xe9s de retard seront appliqu\xe9es au taux de 3 fois le taux d'int\xe9r\xeat l\xe9gal, ainsi qu'une indemnit\xe9 forfaitaire de 40€ pour frais de recouvrement.`},{title:"Article 7 - Livraison",content:`**7.1 D\xe9lais**
Les d\xe9lais de livraison sont donn\xe9s \xe0 titre indicatif :
- Produits en stock : 2-3 semaines
- Produits sur commande : 3-6 semaines

**7.2 Frais de livraison**
- France m\xe9tropolitaine : GRATUIT
- Belgique, Luxembourg, Suisse : sur devis
- Autres destinations : nous consulter

**7.3 Modalit\xe9s**
La livraison est effectu\xe9e sur palette, avec camion \xe9quip\xe9 d'un hayon. Le client doit s'assurer de l'accessibilit\xe9 du lieu de livraison.

**7.4 R\xe9ception**
\xc0 la r\xe9ception, le client doit v\xe9rifier l'\xe9tat des colis et \xe9mettre des r\xe9serves pr\xe9cises sur le bon de livraison en cas de dommage. Toute r\xe9clamation doit \xeatre confirm\xe9e par lettre recommand\xe9e dans les 48 heures.`},{title:"Article 8 - Droit de r\xe9tractation",content:`**8.1 Pour les particuliers**
Conform\xe9ment \xe0 l'article L221-18 du Code de la consommation, le client particulier dispose d'un d\xe9lai de 14 jours \xe0 compter de la r\xe9ception des produits pour exercer son droit de r\xe9tractation, sans avoir \xe0 justifier de motifs ni \xe0 payer de p\xe9nalit\xe9s.

**8.2 Exclusions**
Le droit de r\xe9tractation ne s'applique pas :
- Aux produits sur mesure ou personnalis\xe9s
- Aux produits descell\xe9s ne pouvant \xeatre renvoy\xe9s pour des raisons d'hygi\xe8ne

**8.3 Modalit\xe9s**
Le client doit notifier sa d\xe9cision par \xe9crit. Les produits doivent \xeatre retourn\xe9s dans leur emballage d'origine, en parfait \xe9tat. Les frais de retour sont \xe0 la charge du client.

**8.4 Remboursement**
Le remboursement sera effectu\xe9 dans un d\xe9lai de 14 jours suivant la r\xe9ception des produits retourn\xe9s.`},{title:"Article 9 - Garanties",content:`**9.1 Garantie l\xe9gale de conformit\xe9**
Conform\xe9ment aux articles L217-4 et suivants du Code de la consommation, le vendeur est tenu de livrer un bien conforme au contrat et r\xe9pond des d\xe9fauts de conformit\xe9 existant lors de la d\xe9livrance.

**9.2 Garantie des vices cach\xe9s**
Conform\xe9ment aux articles 1641 et suivants du Code civil, le vendeur est tenu de la garantie \xe0 raison des d\xe9fauts cach\xe9s de la chose vendue.

**9.3 Garantie fabricant**
Les parquets Natura Parquets b\xe9n\xe9ficient d'une garantie fabricant de 25 ans en usage r\xe9sidentiel normal, couvrant les d\xe9fauts de fabrication.

Cette garantie ne couvre pas :
- L'usure normale
- Les dommages dus \xe0 une pose incorrecte
- Les dommages dus \xe0 un entretien inappropri\xe9
- Les variations naturelles du bois`},{title:"Article 10 - R\xe9clamations",content:`Toute r\xe9clamation doit \xeatre adress\xe9e par \xe9crit \xe0 :

EPENON Active SARL
6 rue du Commerce
68420 Herrlisheim-pr\xe8s-Colmar
Email : contact@natura-parquets.fr

Le client doit conserver la preuve d'achat et joindre des photos en cas de r\xe9clamation relative \xe0 un d\xe9faut.`},{title:"Article 11 - Propri\xe9t\xe9 intellectuelle",content:`La marque "Natura Parquets", le logo et l'ensemble des contenus du site sont la propri\xe9t\xe9 exclusive de EPENON Active SARL. Toute reproduction est interdite sans autorisation.`},{title:"Article 12 - Donn\xe9es personnelles",content:`Les donn\xe9es personnelles collect\xe9es sont trait\xe9es conform\xe9ment \xe0 notre Politique de confidentialit\xe9 et au RGPD. Pour plus d'informations, consultez nos Mentions l\xe9gales.`},{title:"Article 13 - M\xe9diation",content:`En cas de litige, le client peut recourir gratuitement au service de m\xe9diation de la consommation. Le m\xe9diateur comp\xe9tent est :

[Nom du m\xe9diateur \xe0 compl\xe9ter]

Conform\xe9ment \xe0 l'article L612-1 du Code de la consommation, le client peut \xe9galement utiliser la plateforme de r\xe8glement en ligne des litiges de l'Union europ\xe9enne : https://ec.europa.eu/consumers/odr`},{title:"Article 14 - Droit applicable",content:`Les pr\xe9sentes CGV sont soumises au droit fran\xe7ais. En cas de litige, les tribunaux fran\xe7ais seront seuls comp\xe9tents, sauf disposition l\xe9gale contraire.`},{title:"Article 15 - Modification des CGV",content:`EPENON Active SARL se r\xe9serve le droit de modifier les pr\xe9sentes CGV \xe0 tout moment. Les CGV applicables sont celles en vigueur \xe0 la date de la commande.`}]},de:{title:"Allgemeine Gesch\xe4ftsbedingungen",lastUpdate:"Letzte Aktualisierung: 20. Februar 2026",sections:[{title:"Artikel 1 - Gegenstand",content:`Diese Allgemeinen Gesch\xe4ftsbedingungen (AGB) regeln den Verkauf von Parkett und zugeh\xf6rigen Produkten durch EPENON Active SARL unter der Marke "Natura Parquets".

Jede Bestellung impliziert die vorbehaltlose Annahme dieser AGB.`},{title:"Artikel 2 - Verk\xe4ufer",content:`**EPENON Active SARL**
SIREN: 881 601 207
USt-IdNr.: FR81881601207
Adresse: 6 rue du Commerce, 68420 Herrlisheim-pr\xe8s-Colmar, Frankreich
E-Mail: contact@natura-parquets.fr`}]},en:{title:"Terms and Conditions",lastUpdate:"Last updated: February 20, 2026",sections:[{title:"Article 1 - Purpose",content:`These Terms and Conditions govern the sales of parquet flooring and related products by EPENON Active SARL, operating under the brand "Natura Parquets".

Any order implies unreserved acceptance of these Terms and Conditions.`},{title:"Article 2 - Seller",content:`**EPENON Active SARL**
SIREN: 881 601 207
VAT Number: FR81881601207
Address: 6 rue du Commerce, 68420 Herrlisheim-pr\xe8s-Colmar, France
Email: contact@natura-parquets.fr`}]}}[e];return(0,s.jsxs)("main",{className:"min-h-screen bg-white",children:[s.jsx(n.default,{}),s.jsx("article",{className:"py-16 px-6 mt-20",children:(0,s.jsxs)("div",{className:"max-w-3xl mx-auto",children:[s.jsx("h1",{className:"font-display text-4xl text-natura-900 mb-2",children:t.title}),s.jsx("p",{className:"text-natura-500 text-sm mb-12",children:t.lastUpdate}),s.jsx("div",{className:"space-y-10",children:t.sections.map((e,t)=>(0,s.jsxs)("section",{children:[s.jsx("h2",{className:"font-semibold text-xl text-natura-900 mb-4",children:e.title}),s.jsx("div",{className:"text-natura-600 leading-relaxed prose prose-natura max-w-none",dangerouslySetInnerHTML:{__html:e.content.replace(/\*\*(.*?)\*\*/g,"<strong>$1</strong>").replace(/\n/g,"<br />")}})]},t))})]})}),s.jsx(i.default,{})]})}},10586:(e,t,r)=>{"use strict";r.r(t),r.d(t,{$$typeof:()=>n,__esModule:()=>a,default:()=>i});let s=(0,r(86843).createProxy)(String.raw`/home/moltbotv2/clawd/projects/natura-parquet/site/src/app/[locale]/cgv/page.tsx`),{__esModule:a,$$typeof:n}=s,i=s.default}};var t=require("../../../webpack-runtime.js");t.C(e);var r=e=>t(t.s=e),s=t.X(0,[638,356,187,691,253,953],()=>r(15723));module.exports=s})();